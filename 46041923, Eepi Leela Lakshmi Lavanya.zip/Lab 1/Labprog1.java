
public class Labprog1 {

	public static void main(String args[])
	{
		int n=3;
		System.out.println(Cubesesvalue(n));
	}
	public static int Cubesesvalue(int n)
	{
		int sum=0;
		for(int a=1;a<=n;a++)
			sum+=a*a*a;
		return sum;
	}
	
}
