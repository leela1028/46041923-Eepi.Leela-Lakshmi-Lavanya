import java.util.Scanner;
public class Labprog3 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
	      int i,a=1,b=1,c=0,t;
	      System.out.println("Enter of t:");
	      t=sc.nextInt();
	      System.out.println("a");
	      System.out.println(" "+b);
	      for(i=0;i<t-2;i++)
	      {
	    	  c=a+b;
	    	  a=b;
	    	  b=c;
	    	  System.out.println(" "+c);
	      }
	      System.out.println("");
	      System.out.println(t+"the Series is: "+c);
	      sc.close();
	}
}
