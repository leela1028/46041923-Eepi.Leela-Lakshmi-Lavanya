

	
	import java.util.Arrays;


	public class Upperlow {
		void upperLowerSort(String[] a) {
			Arrays.sort(a);
			int s=(a.length);
			System.out.println(s);
			for(int i=0;i<s/2;i++)
			{
				System.out.println(a[i].toLowerCase());
			}
			for(int i=s/2;i<s;i++)
			{
				System.out.println(a[i].toUpperCase());
			}
			for(int i=0;i<a.length;i++)
				System.out.println(a[i]);
		}
		public static void main(String[] args){
			String str[]= {"leela","lakshmi","lavanya","Sindhu"};
			Upperlow s2=new Upperlow();
			s2.upperLowerSort(str);
		}
	}

