
import java.util.*;
	import java.io.*;
	
	
public class Characters {
	
	            public static void main(String args[])throws IOException
	            {
	           int nl=1,nw=0;           
	            char ch;
	            Scanner scr=new Scanner(System.in);
	            System.out.print("Enter File name: ");
	            String str=scr.nextLine();
	            FileInputStream fs=new FileInputStream(str);
	             int n=fs.available();
	               for(int i=0;i<n;i++)
	                {
	                                    ch=(char)fs.read();
	                                    if(ch=='\n')
	                                    nl++;
	                                    else if(ch==' ')
	                                                nw++;
	                                                                       
	                 }
	                        System.out.println("\nNumber of lines : "+nl);
	                        System.out.println("\nNumber of words : "+(nl+nw));
	                        System.out.println("\nNumber of characters : "+n);
	                       

	            }
	}


