package com.cg.eis.bean;

public class EmployeService {
	public void information();
	public void insuranceScheme();
	public void display();	

}
