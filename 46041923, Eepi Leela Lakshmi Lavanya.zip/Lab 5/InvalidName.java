

	public class InvalidName extends Exception{
		public InvalidName(String message) {
			super(message);
		}
	}


