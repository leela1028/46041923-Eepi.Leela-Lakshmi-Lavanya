package simplilearn;
import java.util.*;

public class ListInterface {
	
	
	
		public static void main(String args[]) {
			List<String> list = new ArrayList<String>();
			list.add("Zanu");
			list.add("Lakshmi");
			list.add("Sindhu");
			list.add("Vishwam");
			for (String Students : list)
				System.out.println(Students);
		}

	}


